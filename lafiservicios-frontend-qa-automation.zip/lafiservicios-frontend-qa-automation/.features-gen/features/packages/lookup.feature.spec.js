// Generated from: features\packages\lookup.feature
import { test } from "playwright-bdd";

test.describe('Consulta de Paquetes', () => {

  test.beforeEach('Antecedentes', async ({ Given, When, And, page }, testInfo) => { if (testInfo.error) return;
    await Given('que abro la ruta "/app/lafiservicios"', null, { page }); 
    await When('hago clic en el botón "Productos"', null, { page }); 
    await And('hago clic en el enlace "Paquetes" del menú', null, { page }); 
  });
  
  test('Consulta de Paquetes', { tag: ['@packages'] }, async ({ When, Then, page }) => { 
    await When('escribo "CLARO" en el campo "Buscar por banco, proveedor o paquete..."', null, { page }); 
    await Then('veo solo el paquete "CLARO"', null, { page }); 
  });

  test('En Paquetes edito el paquete CLARO Cambio únicamente el Nombre Inglés de PAQUETODO 2 a PAQ', { tag: ['@packages'] }, async ({ When, Then, page }) => { 
    await When('edito el paquete "paquetes"', null, { page }); 
    await Then('veo solo el paquete "paquetes"', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features\\packages\\lookup.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":12,"pickleLine":10,"tags":["@packages"],"steps":[{"pwStepLine":7,"gherkinStepLine":6,"keywordType":"Context","textWithKeyword":"Dado que abro la ruta \"/app/lafiservicios\"","isBg":true,"stepMatchArguments":[{"group":{"start":17,"value":"\"/app/lafiservicios\"","children":[{"start":18,"value":"/app/lafiservicios","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":8,"gherkinStepLine":7,"keywordType":"Action","textWithKeyword":"Cuando hago clic en el botón \"Productos\"","isBg":true,"stepMatchArguments":[{"group":{"start":22,"value":"\"Productos\"","children":[{"start":23,"value":"Productos","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":9,"gherkinStepLine":8,"keywordType":"Action","textWithKeyword":"Y hago clic en el enlace \"Paquetes\" del menú","isBg":true,"stepMatchArguments":[{"group":{"start":23,"value":"\"Paquetes\"","children":[{"start":24,"value":"Paquetes","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"Cuando escribo \"CLARO\" en el campo \"Buscar por banco, proveedor o paquete...\"","stepMatchArguments":[{"group":{"start":8,"value":"\"CLARO\"","children":[{"start":9,"value":"CLARO","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":28,"value":"\"Buscar por banco, proveedor o paquete...\"","children":[{"start":29,"value":"Buscar por banco, proveedor o paquete...","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"Entonces veo solo el paquete \"CLARO\"","stepMatchArguments":[{"group":{"start":20,"value":"\"CLARO\"","children":[{"start":21,"value":"CLARO","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":17,"pickleLine":14,"tags":["@packages"],"steps":[{"pwStepLine":7,"gherkinStepLine":6,"keywordType":"Context","textWithKeyword":"Dado que abro la ruta \"/app/lafiservicios\"","isBg":true,"stepMatchArguments":[{"group":{"start":17,"value":"\"/app/lafiservicios\"","children":[{"start":18,"value":"/app/lafiservicios","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":8,"gherkinStepLine":7,"keywordType":"Action","textWithKeyword":"Cuando hago clic en el botón \"Productos\"","isBg":true,"stepMatchArguments":[{"group":{"start":22,"value":"\"Productos\"","children":[{"start":23,"value":"Productos","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":9,"gherkinStepLine":8,"keywordType":"Action","textWithKeyword":"Y hago clic en el enlace \"Paquetes\" del menú","isBg":true,"stepMatchArguments":[{"group":{"start":23,"value":"\"Paquetes\"","children":[{"start":24,"value":"Paquetes","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"Cuando edito el paquete \"paquetes\"","stepMatchArguments":[{"group":{"start":17,"value":"\"paquetes\"","children":[{"start":18,"value":"paquetes","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":16,"keywordType":"Outcome","textWithKeyword":"Entonces veo solo el paquete \"paquetes\"","stepMatchArguments":[{"group":{"start":20,"value":"\"paquetes\"","children":[{"start":21,"value":"paquetes","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end