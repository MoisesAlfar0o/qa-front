---
description: Crea una prueba E2E nueva (Gherkin en español + steps) a partir de una descripción en lenguaje natural
argument-hint: <dónde, qué haces y qué debe pasar> [--sin-pausa]
---

Crea una prueba E2E nueva para LAFISErvicios a partir de esta descripción:

$ARGUMENTS

Sigue las convenciones de `CLAUDE.md` (nombres de archivo en inglés, Gherkin en español, selectores,
aserciones) y el flujo de `docs/workflow.md`. **No uses el agente `bdd-planner`**: la persona ya
decidió qué se prueba; tu trabajo es traducirlo a Gherkin y automatizarlo.

Si no hay descripción, pídela con este formato y detente:

> **Dónde** (pantalla o área), **qué haces** (acciones) y **qué debe pasar** (resultado esperado).
> Ejemplo: "En Servicios, país Nicaragua, busco "Agua" y debo ver solo servicios cuyo nombre
> contenga "Agua"".

## 1. Entiende la petición

- Si falta el **resultado esperado** o es ambiguo, **pregunta antes de escribir nada**. No lo deduzcas
  mirando lo que hace la aplicación: así una prueba terminaría validando un defecto como si fuera
  correcto.
- Si la descripción implica una acción con **efecto real** (crear, editar, eliminar, activar o
  desactivar, aprobar, reprocesar pagos, cargar deudas, notificar a clientes…), **detente y
  pregunta**. Hoy las pruebas corren con el usuario personal de quien inició sesión (ver
  `docs/adr/0002-temporary-manual-login.md`) y no deben modificar datos. Por defecto, solo flujos de
  lectura: consultas, filtros, listados y navegación.
- Si la descripción es vaga (por ejemplo, "prueba servicios"), pide que la concreten. Si la persona
  quiere que explores la pantalla y le propongas escenarios, sugiérele el agente `bdd-planner`.
- Ignora la marca `--sin-pausa` al interpretar la descripción (se usa en el paso 4).

## 2. Reutiliza antes de crear

Lee `steps/common.steps.ts`, los `steps/<area>/*.steps.ts` y los `features/**/*.feature` existentes, y
haz la lista de frases disponibles. Si ya existe un `.feature` para esa funcionalidad, agrega ahí el
escenario en lugar de crear otro archivo.

## 3. Escribe el `.feature`

- Archivo: `features/<area>/<feature>.feature`, con nombre en **inglés** (minúsculas, kebab-case, sin
  tildes). El texto Gherkin va en **español**, con `# language: es` en la primera línea.
- `<area>` es el segmento de ruta bajo `/app/lafiservicios/managements/`: `approvals`, `categories`,
  `channels`, `channels-catalog`, `collect-configurations`, `countries`, `debts`, `global-cutoff`,
  `notifications`, `packages`, `payment-event-trail`, `payments`, `providers`, `services`,
  `settlements` o `tax-types`. Las pruebas de humo van en `features/smoke/`.
- Etiqueta la característica con `@<area>`. Añade `@smoke` solo a un escenario crítico y rápido.
- Incluye la historia de usuario (`Como … / Quiero … / Para …`). Usa `Antecedentes` para el arranque
  común y `Esquema del escenario` + `Ejemplos` si el flujo se repite con distintos datos.
- **Reutiliza literalmente las frases existentes.** Crea una frase nueva solo si ninguna sirve; en ese
  caso, en lenguaje de negocio (qué hace la persona, no cómo) y con los datos entre comillas dobles o
  como números, para que sea reutilizable.
- Escribe el resultado esperado tal como lo dio la persona. Sin datos reales de clientes ni
  credenciales.

## 4. Revisión del `.feature`

Muestra el `.feature` completo y la lista de **frases nuevas** que habrá que implementar, y **detente a
esperar la aprobación** de la persona (es la revisión del flujo de trabajo). Solo si la descripción
incluye `--sin-pausa`, continúa sin esperar.

## 5. Implementa los pasos

Usa el agente `bdd-generator` para implementar los pasos que falten: ejecuta los escenarios en el
navegador real, saca los selectores comprobados y escribe los steps en `steps/`. Pásale el texto del
escenario nuevo.

Si falla por la sesión ("No hay una sesión guardada" o "La sesión guardada expiró"), **no intentes
iniciar sesión ni escribir credenciales**: pide a la persona que ejecute `pnpm auth:manual` y reintenta
cuando te avise.

## 6. Verifica

Ejecuta el escenario nuevo y después toda la suite:

```bash
pnpm bddgen && npx playwright test --project=setup --project=bdd --grep "<nombre del escenario>"
pnpm test
```

Corrige los steps hasta que pase.

- No edites `.features-gen/`: se regenera con cada `bddgen`.
- No cambies el resultado esperado para que pase. Si la aplicación no se comporta como se describió,
  deja el paso bien implementado, marca el escenario con `@fixme` y un comentario
  `# POSIBLE DEFECTO: <qué pasa en realidad vs. qué se esperaba>`, y repórtalo.

## 7. Cierra

Resume en pocas líneas: archivos creados o modificados, frases nuevas, resultado de `pnpm test` y
posibles defectos. **No hagas commit ni push.** Sugiere el nombre de rama
(`test/<TICKET>-<descripcion>`) y recuerda que el cambio se revisa en un pull request.
